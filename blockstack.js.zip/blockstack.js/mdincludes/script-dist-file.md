```html
<script src="https://unpkg.com/blockstack@19.2.5/dist/blockstack.js" integrity="sha384-89fUBwtmijI3gv30FamqS32y050s8LlxKvr6qRS/RVVQjijZVvsJ8Q4iMM1Jm9EQ" crossorigin="anonymous"></script>
```