/**
* @ignore
*/
declare const config: {
    network: import("./network").AladinNetwork;
    logLevel: string;
};
export { config };
