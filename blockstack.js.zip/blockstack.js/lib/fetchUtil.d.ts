/** @ignore */
export declare function fetchPrivate(input: RequestInfo, init?: RequestInit): Promise<Response>;
