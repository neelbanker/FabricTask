/**
 * Look up a user profile by aladin ID
 *
 * @param {string} username - The Aladin ID of the profile to look up
 * @param {string} [zoneFileLookupURL=null] - The URL
 * to use for zonefile lookup. If falsey, lookupProfile will use the
 * aladin.js [[getNameInfo]] function.
 * @returns {Promise} that resolves to a profile object
 */
export declare function lookupProfile(username: string, zoneFileLookupURL?: string): Promise<any>;
