/* eslint-disable */
document.addEventListener('DOMContentLoaded', function (event) {
  document.getElementById('signin-button').addEventListener('click', function () {
    aladin.redirectToSignIn()
  })
  document.getElementById('signout-button').addEventListener('click', function () {
    aladin.signUserOut(window.location.origin)
  })

  function showProfile(profile) {
    var person = new aladin.Person(profile)
    document.getElementById('heading-name').innerHTML = person.name()
    document.getElementById('avatar-image').setAttribute('src', person.avatarUrl())
    document.getElementById('section-1').style.display = 'none'
    document.getElementById('section-2').style.display = 'block'
  }

  if (aladin.isUserSignedIn()) {
    const userData = aladin.loadUserData()
    showProfile(userData.profile)
  } else if (aladin.isSignInPending()) {
    aladin.handlePendingSignIn().then(userData => {
      showProfile(userData.profile)
    })
  }
})
